package es.ubu.lsi.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class ChatServerStarter {

    public ChatServerStarter() {
        start();
    }

    public void start() {
        try {
            ChatServerImpl server = new ChatServerImpl();
            ChatServer stub = (ChatServer) UnicastRemoteObject.exportObject(server, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind("/servidor", stub);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
