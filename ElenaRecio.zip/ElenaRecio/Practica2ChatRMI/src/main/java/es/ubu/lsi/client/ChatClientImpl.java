package es.ubu.lsi.client;

import java.rmi.RemoteException;
import es.ubu.lsi.common.ChatMessage;
import es.ubu.lsi.server.ChatServer;

public class ChatClientImpl implements ChatClient {
    
    private int id;
    private String nickname;
    private ChatServer server;
    
    public ChatClientImpl(String nickname) throws RemoteException{
    	super();
        this.nickname = nickname;
    }
    
    public ChatServer getServer() {
    	return server;
    }
    
    public void setServer(ChatServer server) {
    	this.server=server;
    }
    @Override
    public int getId() throws RemoteException {
        return id;
    }

    @Override
    public void setId(int id) throws RemoteException {
        this.id = id;
    }

    @Override
    public void receive(ChatMessage msg) throws RemoteException {
        System.out.println(msg.getNickname() + ": " + msg.getMessage());
    }

    @Override
    public String getNickName() throws RemoteException {
        return nickname;
    }
}
