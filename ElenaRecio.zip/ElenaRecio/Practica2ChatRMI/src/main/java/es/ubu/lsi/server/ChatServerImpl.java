package es.ubu.lsi.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

import es.ubu.lsi.client.ChatClient;
import es.ubu.lsi.common.ChatMessage;

/**
 * Implementation of ChatServer interface.
 * Handles client registration, message broadcasting, and server shutdown.
 * 
 * @author Raúl Marticorena
 * @author Joaquin P. Seco
 */
public class ChatServerImpl extends UnicastRemoteObject implements ChatServer {

    private static final long serialVersionUID = 1L;
    private Map<Integer, ChatClient> clients;
    private int nextClientId;

    public ChatServerImpl() throws RemoteException {
        clients = new HashMap<>();
        nextClientId = 1;
    }

    @Override
    public synchronized int checkIn(ChatClient client) throws RemoteException {
        clients.put(nextClientId, client);
        System.out.println(client.getNickName() + " has joined the chat.");
        return nextClientId++;
    }

    @Override
    public synchronized void logout(ChatClient client) throws RemoteException {
        clients.remove(client.getId());
        System.out.println(client.getNickName() + " has left the chat.");
    }

    @Override
    public synchronized void publish(ChatMessage msg) throws RemoteException {
        System.out.println(msg.getNickname() + ": " + msg.getMessage());
        for (ChatClient client : clients.values()) {
            client.receive(msg);
        }
    }

    @Override
    public synchronized void shutdown(ChatClient client) throws RemoteException {
        System.out.println("Server is shutting down...");
        System.exit(0);
    }
}
